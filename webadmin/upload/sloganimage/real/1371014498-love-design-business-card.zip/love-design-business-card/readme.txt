PixelsDaily
=======================
Name:	Love Design Business Card
Type:	PSD
Author:	Francisco Neves


Notes
=======================
A "love design" business card, with simple colours, graphics, and typography. A funky basis on which to build your own brand!




Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit PixelsDaily for the original creation:

http://creativecommons.org/licenses/by/3.0/