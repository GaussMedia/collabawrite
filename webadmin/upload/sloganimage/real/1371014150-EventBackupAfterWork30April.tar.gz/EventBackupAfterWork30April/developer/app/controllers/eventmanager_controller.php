<?php
class EventmanagerController extends AppController {

	var $name = 'Eventmanager';
                  var $uses = array('User'); 
                  function index() {
                              $this->layout='frontend';
	}
                  function add() {
                             $this->layout='frontend';
	}
}
?>