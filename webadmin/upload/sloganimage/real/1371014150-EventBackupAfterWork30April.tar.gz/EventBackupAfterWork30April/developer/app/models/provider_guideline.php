<?php
class ProviderGuideline extends AppModel {
	var $name = 'ProviderGuideline';
	var $validate = array(
		'title' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the title',
			),
			'unique' => array(
				'rule' => array('isUnique'),
				'message' => 'Title already Exists',
				'on'=>'create',
			),
		),
		'doc_name'  => array(
                    'checksize' => array(
                        'rule' => array('checkSize',true),
                        'message' => 'Invalid File size',
                        'on' => 'create'
                    ),
                    'checktype' =>array(
                        'rule' => array('checkType',true),
                        'message' => 'File type not supported',
                        'on' => 'create'
                    ),
                    'checkupload' =>array(
                        'rule' => array('checkUpload', true),
                        'message' => 'Image of claim form not selected',
                        'on' => 'create'
                    ),		
                ),
   );
        
     	//Validation Functions for Image upload
function checkUpload($data, $required = false){
        $data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        //debug($data);
        if($required && $data['error'] !== 0){
            return false;
        }
        if($data['size'] == 0){
            return false;
        }
        return true;
        //if($required and $data)
    }

    function checkType($data, $required = false,$allowedMime = null){
		$data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        $allowedMime = array('application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/msword');
        if(!in_array($data['type'], $allowedMime)){
             return false;
        }
        return true;
    }

    function checkSize($data, $required = false){
        $data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        if($data['size'] == 0||$data['size']/1024 > 2050){
            return false;
        }
        return true;
    }
   
   public function beforeSave(array $options) {
		return true;
	}     
}