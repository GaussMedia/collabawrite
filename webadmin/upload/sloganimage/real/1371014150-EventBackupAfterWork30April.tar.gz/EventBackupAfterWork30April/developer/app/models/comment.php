<?php
class Comment extends AppModel {
	var $name = 'Comment';
	var $validate = array();
	
	function spentTime($time){
			$timespent=time()-$time;
			
			$days = floor($timespent / (60 * 60 * 24));
			$remainder = $timespent % (60 * 60 * 24);
			$hours = floor($remainder / (60 * 60));
			$remainder = $remainder % (60 * 60);
			$minutes = floor($remainder / 60);
			$seconds = $remainder % 60;
			
			if($days > 0)
			$return= date('j-M-Y, g:s a', $time);
			elseif($days == 0 && $hours == 0 && $minutes == 0)
			$return= "few seconds ago";
			
			elseif($days == 0 && $hours == 0 && $minutes > 0)
			$return= $minutes.' minutes ago';
			
			elseif($days == 0 && $hours > 0)
			$return= $hours.' hours ago';
			else
			$return= "few seconds ago";
			
			return $return;
			
			}
}