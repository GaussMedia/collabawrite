<?php
class Jobapplication extends AppModel {
	var $name = 'Jobapplication';
	var $validate = array(
   );
        
     	//Validation Functions for Image upload
function checkUpload($data, $required = false){
        $data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        //debug($data);
        if($required && $data['error'] !== 0){
            return false;
        }
        if($data['size'] == 0){
            return false;
        }
        return true;
        //if($required and $data)
    }

    function checkType($data, $required = false,$allowedMime = null){
		$data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        $allowedMime = array('application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/msword');
        if(!in_array($data['type'], $allowedMime)){
             return false;
        }
        return true;
    }

    function checkSize($data, $required = false){
        $data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        if($data['size'] == 0||$data['size']/1024 > 1024){
            return false;
        }
        return true;
    }
     
}