<?php
class LogoController extends AppController {

	var $name = 'Logo';
                  var $uses = array('Logo');
                 
                  function webadmin_index() {
		$this->layout='webadmin';		
		$this->paginate = array( 
			'limit' =>10,
            		//'conditions'=>array('type'=>'doctor'),
			'order' => array('Logo.id' => 'asc'));
			$logos = $this->paginate('Logo');		
		$this->set('logos', $logos);
	}
                function webadmin_edit($id = null) {
		$this->layout='webadmin';
		$slider=$this->Logo->findById($id);
		$this->set('sliders',$slider);
		if (!$id && empty($this->data)) {
			$this->Session->setFlash('Updation not successfull','flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if($this->data){
                                                       $error=0;   
			if(!empty($this->data['Logo']['image']['name'])){
				
                                                                 if($this->data['Logo']['image']['type']=='image/jpeg' || $this->data['Logo']['image']['type']=='image/gif'|| $this->data['Logo']['image']['type']=='image/png'){
                                                                         $RandomNumber 	= rand(0, 9999999999); 
				$ImageName 		= str_replace(' ','-',strtolower($this->data['Logo']['image']['name'])); 
				$ImageSize 		= $this->data['Logo']['image']['size']; 
				$TempSrc	 	= $this->data['Logo']['image']['tmp_name'];
				$ImageType	 	= $this->data['Logo']['image']['type']; 
				$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
				$ImageExt = str_replace('.','',$ImageExt);
				$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
				$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
                                                                        @unlink(INCLUDE_PATH.'logo/'.$slider['Logo']['image']);
				if(move_uploaded_file($TempSrc,INCLUDE_PATH.'logo/'.$NewImageName)){
					
					$this->data['Logo']['image']=$NewImageName;	
				}
                                                                } else{
                                                                        $error=1;       
                                                                        $this->Session->setFlash('Image is invalid,Please use Image with extension( .jpg, .png, .gif) ','flash_error');
                                                              }
			}
			 if($error==0){
                                                        //die('sdfcsd');
                                                                if($this->Logo->save($this->data)){
                                                                        $this->Session->setFlash('Logo details updated successfully','flash_success');
                                                                        $this->redirect(array('action' => 'index'));
                                                                }
                                                    }              
		}
		
	}
}
?>