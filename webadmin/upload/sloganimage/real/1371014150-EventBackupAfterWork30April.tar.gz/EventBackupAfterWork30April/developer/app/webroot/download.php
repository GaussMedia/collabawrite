<?php // Send file headers
$filename=trim($_REQUEST['file']);


// Modify this line to indicate the location of the files you want people to be able to download

// This path must not contain a trailing slash. ie. /temp/files/download

//$download_path = "/";

// Make sure we can't download files above the current directory location.

$file = str_replace("reports/", "", $filename);

// Make sure we can't download .ht control files.

// Combine the download path and the filename to create the full path to the file.

$file = "$file";


// Test to ensure that the file exists.





// Extract the type of file which will be sent to the browser as a header

$type = filetype($file);



// Send file headers

header("Content-type: $type");

header("Content-Disposition: attachment;filename=$filename");

header("Content-Transfer-Encoding: binary");

header('Pragma: no-cache');

header('Expires: 0');

// Send the file contents.

set_time_limit(0);

readfile($file);


?>
