<?php
class Procedurerequest extends AppModel {
	var $name = 'Procedurerequest';
	var $validate = array(
		'first_name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the first name',
			),
			'unique' => array(
				'rule' => array('isUnique'),
				'message' => 'First name already exists',
				'on'=>'create',
			),
		),
		'last_name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the last name',
			),
                        'unique' => array(
				'rule' => array('isUnique'),
				'message' => 'Last name already exists',
				'on'=>'create',
			),
		),
		'insurance_no' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the insurance no',
			),
                        'unique' => array(
				'rule' => array('isUnique'),
				'message' => 'Insurance number already exists',
				'on'=>'create',
			),
		),
		'cost' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the cost',
			),
		),
		'description' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the description',
			),
		),
		'image'  => array(
                    'checksize' => array(
                        'rule' => array('checkSize',true),
                        'message' => 'Invalid File size',
                        'on' => 'create'
                    ),
                    'checktype' =>array(
                        'rule' => array('checkType',true),
                        'message' => 'File type not supported',
                        'on' => 'create'
                    ),
                    'checkupload' =>array(
                        'rule' => array('checkUpload', true),
                        'message' => 'Image of claim form not selected',
                        'on' => 'create'
                    ),
		),
   );
   
   	//Validation Functions for Image upload
function checkUpload($data, $required = false){
        $data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        //debug($data);
        if($required && $data['error'] !== 0){
            return false;
        }
        if($data['size'] == 0){
            return false;
        }
        return true;
        //if($required and $data)
    }

    function checkType($data, $required = false,$allowedMime = null){
		$data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        $allowedMime = array('image/gif','image/jpeg','image/pjpeg','image/png','application/pdf');
        if(!in_array($data['type'], $allowedMime)){
             return false;
        }
        return true;
    }

    function checkSize($data, $required = false){
        $data = array_shift($data);
        if(!$required && $data['error'] == 4){
            return true;
        }
        if($data['size'] == 0||$data['size']/1024 > 2050){
            return false;
        }
        return true;
    }
   
   public function beforeSave(array $options) {
		return true;
	}
}