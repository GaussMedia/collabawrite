<?php
class Admin extends AppModel {
	var $name = 'Admin';
	var $validate = array(
		'old_password' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter old password',
			),
			'checkoldpass' => array(
				'rule' => 'checkCurrentPassword',
				'message' => 'Old password does not match'
			),
		),
		'password' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your Passwords',
			 ),
			'password_confirmation' => array(
				'rule' => array('matchPasswords'),
				'message' => 'Passwords do not match',
			),
		),
		'password' => array(
			'checkpasswordstrength' => array(
				'rule' => array('checkPasswordStrength'),
				'message' => 'Password must have atleast 5 charaters',
			),
		),
		'email' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your email',
			),
		),
		'fax' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your fax number',
			),
		),
		'phone' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your phone number',
			),
		),
	);
	public function matchPasswords($data) {
        if($data['password'] == $this->data[$this->alias]['password_confirmation']) return true;
        $this->invalidate('password_confirmation', 'Passwords do not match');
        return false;
    }
	public function hashPasswords($data) {
        if(isset($this->data[$this->alias]['password']))
            $this->data[$this->alias]['password'] = Security::hash($this->data[$this->alias]['password'], null, true);
        
        return $data;
    }
	public function beforeSave(array $options) {
		$this->hashPasswords(null, true);
		return true;
	}
	public function checkCurrentPassword($data) {
		$password = $this->field('password');
		return(Security::hash($data['old_password'], null, true) == $password);
	}
	public function checkPasswordStrength($data) {
		if(strlen($data['password']) < 5) return false;
		else return true;		
	}
}