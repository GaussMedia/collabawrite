<?php
class BlogsController extends AppController {

	var $name = 'Blogs';
                  var $uses = array('Blog');    
                  function webadmin_add() {
		$this->layout='webadmin';
		if($this->data){
                        $this->data['Blog']['userid'] = $this->Auth->user('id');
                        $this->data['Blog']['slug'] = $this->slug($this->data['Blog']['title']);
			if($this->Blog->save($this->data)){
				$this->Session->setFlash('Blog added successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
	}
                function webadmin_index() {
		$this->layout='webadmin';		
		$this->paginate = array( 
			'limit' =>10,
            		//'conditions'=>array('type'=>'doctor'),
			'order' => array('Blog.id' => 'asc'));
			$blog = $this->paginate('Blog');		
		$this->set('blogs', $blog);
	}
                    function webadmin_changestatus($id) {
		$this->autoRender =false;
		$blog = $this->Blog->findById($id);
		if($blog['Blog']['status']=='1'){
			$blog['Blog']['status'] = '0';
		}
		elseif($blog['Blog']['status']=='0'){
			$blog['Blog']['status'] = '1';
		}
		if($this->Blog->save($blog)){
			$this->Session->setFlash('Blog status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/blogs');
	}
                 function webadmin_changestatusall() {
		$this->autoRender =false;
		$blogArr = $_POST['chk'];
		if($this->data['Blog']['sel_action']=='publish'){
			foreach($blogArr as $v){
				$blog = $this->Blog->findById($v);
				$blog['Blog']['status']='1';
				$this->Blog->save($blog);
			}
			$this->Session->setFlash('Selected Blogs Activated successfully','flash_success');
		}
		elseif($this->data['Blog']['sel_action']=='unpublish'){ 
			foreach($blogArr as $v){
				$blog = $this->Blog->findById($v);
				$blog['Blog']['status']='0';
				$this->Blog->save($blog);
			}
			$this->Session->setFlash('Selected Blogs De-activated successfully','flash_success');
		}
		elseif($this->data['Blog']['sel_action']=='delete'){
			foreach($blogArr as $v){
				$this->Blog->delete($v);
			}
			$this->Session->setFlash('Selected Blogs deleted successfully','flash_success');
		}
                                    else{
			$this->Session->setFlash('Please select the Blog.','flash_error');
		}
                
		$this->redirect('/webadmin/blogs');
	}
                 function webadmin_delete($id) {
		if($this->Blog->delete($id)){
			$this->Session->setFlash('Blog deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/blogs');
	}
                function webadmin_details($id) {
		$this->layout='webadmin';
		$this->set('blog', $this->Blog->findById($id));
	}
                function webadmin_edit($id = null) {
		$this->layout='webadmin';
		if($this->data){
			if($this->Blog->save($this->data)){
				$this->Session->setFlash('Blog updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
		$this->set('blogs', $this->Blog->findById($id));
	}
        
}
?>