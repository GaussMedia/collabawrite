<?php
class LoginController extends AppController {

	var $name = 'Login';
	var $uses=array('Admin','User','Loginlog','Guideline');
	function beforeFilter() { 
		parent::beforeFilter(); 
        $this->Auth->allow(array('step1','step2'));
		$this->Auth->autoRedirect = false;
    }
	function webadmin_index() {
		$this->layout='adminlogin';
		if ($this->Auth->login()) {
			////save login logs/////
			$ip_address=$_SERVER['REMOTE_ADDR'];
			$log_data['Loginlog']['user_id']=$this->Auth->user('id');
			$log_data['Loginlog']['type']=$this->Auth->user('type');
			$log_data['Loginlog']['ip']=$ip_address;
			$log_data['Loginlog']['starttime']=time();
			$this->Loginlog->save($log_data);
			$insert_id=$this->Loginlog->getLastInsertID();
			//$log_data['Loginlog']['endtime']=$this->Auth->user('type');
			$_SESSION['Auth']['User']['logid']=$insert_id;
			//$this->Auth->user('logid')=$insert_id;
			$this->redirect(array('controller'=>'dashboard','action'=>'index','prefix'=>'webadmin'));	
		}
	}
	function webadmin_logout() {
		$this->Loginlog->id = $this->Auth->user('logid');
		$this->Loginlog->saveField('endtime',time());
		$this->redirect($this->Auth->logout());
	}
	function step1() {
		$this->layout='frontend';
	}
	
	function step2($type = null) {
		$this->set('guideline',$this->Guideline->findByPage('login'));
		$ip_address=$_SERVER['REMOTE_ADDR'];
		$this->layout='frontend';
		if(!isset($_SESSION['sign_attempt'])){
			$_SESSION['sign_attempt']=0;
		}
		$this->set('type', $type);
		if($this->data){
			if($_SESSION['sign_attempt']<3){
				if ($this->Auth->login()) {
					////save login logs/////
					$log_data['Loginlog']['user_id']=$this->Auth->user('id');
					$log_data['Loginlog']['type']=$this->Auth->user('type');
					$log_data['Loginlog']['ip']=$ip_address;
					$log_data['Loginlog']['starttime']=time();
					$this->Loginlog->save($log_data);
					$insert_id=$this->Loginlog->getLastInsertID();
					//$log_data['Loginlog']['endtime']=$this->Auth->user('type');
					$_SESSION['Auth']['User']['logid']=$insert_id;
					//$this->Auth->user('logid')=$insert_id;
					if($this->Auth->user('type')=='doctor'){
						if($_REQUEST['type']=="doctor"){
							$this->redirect(array('controller'=>'doctors','action'=>'index'));
						}else{
							$this->Auth->logout();	
							$this->Session->setFlash('Invalid username or password.','flash_error');
							$this->redirect(array('controller'=>'login','action'=>'step1'));
						}
					}else
					if($this->Auth->user('type')=='provider'){
						if($_REQUEST['type']=="provider"){
							$this->redirect(array('controller'=>'providers','action'=>'index'));
						}else{
							$this->Auth->logout();	
							$this->Session->setFlash('Invalid username or password.','flash_error');
							$this->redirect(array('controller'=>'login','action'=>'step1'));
						}
					}
				}
				else{
					$_SESSION['sign_attempt']+=1;
					$this->Session->setFlash('Invalid username or password.','flash_error');
				}
			}
			else{
				$this->Session->setFlash('Your Account has been blocked.','flash_error');
			}
		}
	}
	
	
	function step2_test() {
		$this->set('guideline',$this->Guideline->findByPage('login'));
		$ip_address=$_SERVER['REMOTE_ADDR'];
		$this->layout='frontend';
		if(!isset($_SESSION['sign_attempt'])){
			$_SESSION['sign_attempt']=0;
		}
		if($this->data){
			if($_SESSION['sign_attempt']<3){
				if ($this->Auth->login()) {
					////save login logs/////
					$log_data['Loginlog']['user_id']=$this->Auth->user('id');
					$log_data['Loginlog']['type']=$this->Auth->user('type');
					$log_data['Loginlog']['ip']=$ip_address;
					$log_data['Loginlog']['starttime']=time();
					$this->Loginlog->save($log_data);
					$insert_id=$this->Loginlog->getLastInsertID();
					//$log_data['Loginlog']['endtime']=$this->Auth->user('type');
					$_SESSION['Auth']['User']['logid']=$insert_id;
					//$this->Auth->user('logid')=$insert_id;
					if($this->Auth->user('type')=='doctor'){
						$this->redirect(array('controller'=>'doctors','action'=>'index'));
					}else
					if($this->Auth->user('type')=='provider'){
						$this->redirect(array('controller'=>'providers','action'=>'index'));
					}
				}
				else{
					$count = $this->User->find('count', array('conditions'=>array('username'=>$this->data['User']['username'])));
					if($count == "1"){
						$_SESSION['sign_attempt']+=1;
					}
					$this->Session->setFlash('Invalid username or password.','flash_error');
				}
			}
			else{
				$this->Session->setFlash('Your Account has been blocked.','flash_error');
			}
		}
	}
	
	function index() {
		if(!isset($_SESSION['sign_attempt'])){
			$_SESSION['sign_attempt']=0;
		}
		$this->layout='login';
		if ($this->Auth->login()) {
                                                    if($this->Auth->user('type')=='event_manager'){
				$this->redirect(array('controller'=>'eventmanager','action'=>'index'));
			}else
			if($this->Auth->user('type')=='event_manager'){
				$this->redirect(array('controller'=>'eventmanager','action'=>'index'));
			}
		}
                                  
	}
	function logout() {
//		$ip_address=$_SERVER['REMOTE_ADDR'];
//		$this->User->id = $this->Auth->user('id');
//		$this->User->saveField('last_login', time());
//		$this->User->saveField('last_ip',$ip_address);
		unset($_SESSION['sign_attempt']);
		unset($_SESSION['push_alert']);
		$this->Loginlog->id = $this->Auth->user('logid');
		$this->Loginlog->saveField('endtime',time());
		$this->redirect($this->Auth->logout());
	}
}
?>