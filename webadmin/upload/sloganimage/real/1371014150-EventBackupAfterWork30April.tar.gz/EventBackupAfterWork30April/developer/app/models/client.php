<?php
class Client extends AppModel {
	var $name = 'Client';
	var $validate = array(
		'first_name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the first name',
			),
			/*'unique' => array(
				'rule' => array('isUnique'),
				'message' => 'Firstname already Exists',
				'on'=>'create',
			),*/
		),
		'last_name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the last name',
			),
		),
		'insurance_no' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter the insurance no',
			),
		),
		
   );
}