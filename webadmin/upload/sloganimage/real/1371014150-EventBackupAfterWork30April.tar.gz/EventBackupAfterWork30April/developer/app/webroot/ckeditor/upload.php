<?php
/*print_r($_FILES);
echo '<br>';*/

//echo $_GET['CKEditorFuncNum'];

//print_r($_SERVER['DOCUMENT_ROOT']);

$fname=time().$_FILES['upload']['name'];
$target = "../files/".$fname;



if(move_uploaded_file($_FILES['upload']['tmp_name'],$target))
{
$url="http://rentalus.pnf-sites.info/developer/app/webroot/files/".$fname;

//$message="success";
$funcNum = $_GET['CKEditorFuncNum'] ;
echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction('$funcNum', '$url', '$message');</script>";

}
else
{
	echo 'Error uploading file!';
}

?>