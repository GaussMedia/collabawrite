<?php
class OtherAdminsController extends AppController {

	var $name = 'OtherAdmins';
	var $uses = array('User','Loginlog','ProviderGuideline','Privilege');
	function beforeFilter() {
		parent::beforeFilter(); 
        //$this->Auth->allow('');
		$user = $this->User->findById($this->Auth->user('id'));
		$logs=$this->Loginlog->find('all',array('conditions'=>array('user_id'=>$this->Auth->user('id')),'limit'=>1,'order'=>'id asc'));
		if(!empty($user['User']['guideline_noti'])){
			$exploded = explode(",", $user['User']['guideline_noti']);	
			$this->set('guidelineCount', $this->ProviderGuideline->find('count', array('conditions'=>array('UNIX_TIMESTAMP(created) >'=>$logs[0]['Loginlog']['starttime'],'status'=>'1','NOT'=>array('id'=>$exploded)))));		
		}
		else{
			$this->set('guidelineCount', $this->ProviderGuideline->find('count', array('conditions'=>array('UNIX_TIMESTAMP(created) >'=>$logs[0]['Loginlog']['starttime'],'status'=>'1'))));	
		}
                }
	function webadmin_index() {
		$this->layout='webadmin';
                
                $this->User->updateAll(array('User.read'=>"'1'"), array('User.read'=>'0')); 
                
		if($this->data['User']['username']){
			$this->paginate = array( 
			'limit' =>10,
			'conditions'=>array('type'=>'other_admin','username LIKE'=>"%".$this->data['User']['username']."%"),
			'order' => array('User.id' => 'desc'));
			$users = $this->paginate('User');
		} 
		else{
			$this->paginate = array(  
			'limit' =>10,
			'conditions'=>array('type'=>'other_admin'),
			'order' => array('User.id' => 'desc'));
			$users = $this->paginate('User');
		}
		
		$this->set('users', $users);
		//////auto complete/////
		$autoFull = $this->User->find('all', array(
			'conditions'=>array('type'=>'other_admin'),
			'order' => array('id' => 'asc'),
			'fields' => array('id', 'username'),
			));
		foreach($autoFull as $auto){
			$autocomplete[] = $auto['User']['username'];
		}
		$autocomplete = @implode('&quot;,&quot;', $autocomplete);
		$this->set('autocomplete', $autocomplete);
		///////////////////////
	}
	function webadmin_details($id) {
		$this->layout='webadmin';
		$this->set('user', $this->User->findById($id));
	}	
	function webadmin_generate_password($id=null) {
		$this->autoRender=false;
		//echo $id;
		if(empty($id)){
			$this->redirect(array('controller'=>'dashboard','action'=>'index','prefix'=>'webadmin'));
		}
		$user = $this->User->findById($id);
		$admin = $this->User->findById(23);
		
		$passToken = $this->generateRandomString();
		$user['User']['password_hint'] = $passToken;
		$user['User']['password'] = Security::hash($passToken, null, true);
		$this->Email->to 		= $user['User']['email'];
		$this->Email->subject 	= 'Password changed - DO NOT REPLY';
		$this->Email->replyTo 	= $admin['User']['email'];
		$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
		$this->Email->template 	= 'change_password';
		$this->Email->sendAs 	= 'both';
		$this->set('User', $user);
		if($this->Email->send()){
                                  if($this->User->save($user,array( 'validate' => true, 'fieldList' => array('password','password_hint') ))){
			
                            $this->Session->setFlash('Password changed successfully','flash_success');	
				$this->redirect(array('controller'=>'other_admins','action'=>'index','prefix'=>'webadmin'));
			}
		}
		else{
			$this->Session->setFlash('Error occured. Try again.','flash_error');
			$this->redirect(array('controller'=>'other_admins','action'=>'index','prefix'=>'webadmin'));
		}
		
	}
	function webadmin_changestatus($id) {
		$this->autoRender =false;
		$user = $this->User->findById($id);
                                    
		$admin = $this->User->findById(23);
		if($user['User']['status']=='1'){
                                                      
			$user['User']['status'] = '0'; 
				$this->Email->to 		= $user['User']['email'];
				$this->Email->subject 	= 'Account de-activated';
				$this->Email->replyTo 	= $admin['User']['email'];
				$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
				$this->Email->template 	= 'account_deactivated_noti';
				$this->Email->sendAs 	= 'both';
				$this->set('User', $user);
				$this->set('admin', $admin);
				$this->Email->send();
		}
		elseif($user['User']['status']=='0'){
			$user['User']['status'] = '1';
			if($user['User']['is_activated']=='0'){	
				$passToken = $this->generateRandomString();
				$user['User']['password_hint'] = $passToken;
				$user['User']['password'] = Security::hash($passToken, null, true);
				$this->Email->to 		= $user['User']['email'];
				$this->Email->subject 	= 'Account activated - DO NOT REPLY';
				$this->Email->replyTo 	= $admin['User']['email'];
				$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
				$this->Email->template 	= 'account_activated_noti';
				$this->Email->sendAs 	= 'both';
				$this->set('User', $user);
				$this->Email->send();
				$user['User']['is_activated'] = '1';
			}
			else{
				$this->Email->to 		= $user['User']['email'];
				$this->Email->subject 	= 'Account activated - DO NOT REPLY';
				$this->Email->replyTo 	= $admin['User']['email'];
				$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
				$this->Email->template 	= 'account_activated_noti';
				$this->Email->sendAs 	= 'both';
				$this->set('User', $user);
				$this->Email->send();
			}
		}
                 //pr($user);die();
		if($this->User->save($user,array( 'validate' => false))){
			$this->Session->setFlash('User status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/other_admins');
	}
	function webadmin_changestatusall() {
		$this->autoRender =false;
		if(!empty($_POST['chk'])){ 
			$usrArr = $_POST['chk'];
			$admin = $this->User->findById(23);
			if($this->data['User']['sel_action']=='publish'){
				foreach($_POST['chk'] as $v){
					$user = $this->User->findById($v);
					$user['User']['status']='1';
					if($user['User']['is_activated']=='0'){
						$passToken = $this->generateRandomString();
						$user['User']['password_hint'] = $passToken;
						$user['User']['password'] = Security::hash($passToken, null, true);
						$this->Email->to 		= $user['User']['email'];
						$this->Email->subject 	= 'Account activated - DO NOT REPLY';
						$this->Email->replyTo 	= $admin['User']['email'];
						$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
						$this->Email->template 	= 'account_activated_noti';
						$this->Email->sendAs 	= 'both';
						$this->set('User', $user);
						$this->Email->send();
						$user['User']['is_activated'] = '1';
					}
					else{
						$this->Email->to 		= $user['User']['email'];
						$this->Email->subject 	= 'Account activated - DO NOT REPLY';
						$this->Email->replyTo 	= $admin['User']['email'];
						$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
						$this->Email->template 	= 'account_activated_noti';
						$this->Email->sendAs 	= 'both';
						$this->set('User', $user);
						$this->Email->send();
					}
					$this->User->save($user,array( 'validate' => false));
				}
				$this->Session->setFlash('Selected Users Activated successfully','flash_success');
			}
			elseif($this->data['User']['sel_action']=='unpublish'){ 
				foreach($usrArr as $v){
					$user = $this->User->findById($v);
					$user['User']['status']='0';
					$this->Email->to 		= $user['User']['email'];
					$this->Email->subject 	= 'Account de-activated';
					$this->Email->replyTo 	= $admin['User']['email'];
					$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
					$this->Email->template 	= 'account_deactivated_noti';
					$this->Email->sendAs 	= 'both';
					$this->set('User', $user);
					$this->set('admin', $admin);
					$this->Email->send();
					$this->User->save($user,array( 'validate' => false));
				}
				$this->Session->setFlash('Selected Users De-activated successfully','flash_success');
			}
			elseif($this->data['User']['sel_action']=='delete'){
				foreach($_POST['chk'] as $v){
					$this->User->delete($v);
				}
				$this->Session->setFlash('Selected Users deleted successfully','flash_success');
			}
		} 
		else{
			$this->Session->setFlash('Please select the users.','flash_error');
		}	
		$this->redirect('/webadmin/other_admins');
	}
	function webadmin_delete($id) {		 
		if($this->User->delete($id)){
			$this->Session->setFlash('User deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/other_admins');
	}
	function webadmin_edit($id = null) {
		$this->layout='webadmin';
		if (!$id && empty($this->data)) {
			$this->Session->setFlash('Updation not successfully','flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if($this->data){
			if($this->User->save($this->data)){
				$this->Session->setFlash('User details updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
		$this->set('users', $this->User->findById($id));
	}
	function webadmin_add_otheradmin() {
		$this->layout='webadmin';
		$privileges=$this->Privilege->find('all',array('conditions'=>array('status'=>1)));
		$parents=$this->Privilege->find('all',array('conditions'=>array('status'=>1),'fields' => array('DISTINCT parent')));
		$this->set('parents',$parents);
		$this->set('privileges',$privileges);
		//pr(array_filter($parents));
		//pr($privileges);
		
		if($this->data){
				$this->data['User']['ref_no'] = mt_rand(10000, 99999);
				$passToken = $this->generateRandomString();
                $this->data['User']['type'] = 'other_admin';
                $this->data['User']['status'] = '1';
				$this->data['User']['password_hint'] = $passToken;
				$this->data['User']['password'] = Security::hash($passToken, null, true);
				if($this->User->save($this->data,array( 'validate' => true, 'fieldList' =>array('ref_no','username','password','password_hint','email','type','status')))){
					$insert_id=$this->User->getLastInsertID();
					$user = $this->User->findById($insert_id);
                    $admin = $this->User->findById(23);
					$this->Email->to 		= $user['User']['email'];
					$this->Email->subject 	= 'Account Created Notification';
					$this->Email->replyTo 	= $admin['User']['email'];
					$this->Email->from 		= 'BlueFast notification <'.$admin['User']['email'].'>';
					$this->Email->template 	= 'otheradmin_signup';
					$this->Email->sendAs 	= 'both';
					$this->set('User', $user);
					$this->Email->send();
					$this->redirect(array('controller'=>'other_admins','action'=>'signup_confirm/'.$insert_id,'prefix'=>'webadmin'));	
				} 
		}
	}	
	function webadmin_signup_confirm($id) {
		$this->layout='webadmin';
		$user = $this->User->findById($id);
		$this->set('user',$user); 
	}	
				
}
?>