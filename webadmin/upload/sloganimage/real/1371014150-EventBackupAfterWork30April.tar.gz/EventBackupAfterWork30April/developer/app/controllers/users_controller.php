<?php
class UsersController extends AppController {
//Dont name your password field as password
	var $name = 'Users';
	var $uses = array('User','Admin','Guideline','Client');
	var $components = array('Recaptcha.Recaptcha');  
	
	//function beforeFilter() {
		//parent::beforeFilter(); 
        //$this->Auth->allow(array('signup_step1','signup','signup_confirm','login_type'));
   // } 
	
	function webadmin_index() {
		$this->layout='webadmin';		
		$this->paginate = array( 
                                    'limit' =>10,
                                    'conditions'=>array('type'=>'event_manager'),
                                    'order' => array('User.id' => 'asc'));
                                    $user = $this->paginate('User');		
                                    $this->set('users', $user);
                }
	
	function webadmin_add() {
		$this->layout='webadmin';
		if($this->data){
				$this->data['User']['ref_no'] = mt_rand(10000, 99999);
				$passToken = $this->generateRandomString();
                                                                        $this->data['User']['type'] = 'event_manager';
                                                                        $this->data['User']['status'] = '1';
				$this->data['User']['password_hint'] = $passToken;
				$this->data['User']['password'] = Security::hash($passToken, null, true);
				if($this->User->save($this->data,array( 'validate' => true, 'fieldList' =>array('ref_no','username','password','password_hint','first_name','last_name','email','status','type','addressline1','addressline2','county','mobile','landline','consultation_fee')))){
					$insert_id=$this->User->getLastInsertID();
					$user = $this->User->findById($insert_id);
                                        
                    $admin = $this->User->findById(23);
					$this->Email->to 		= $user['User']['email'];
					$this->Email->subject 	= 'Account Created Notification';
					$this->Email->replyTo 	= $admin['User']['email'];
					$this->Email->from 		= 'Event notification <'.$admin['User']['email'].'>';
					$this->Email->template 	= 'eventuser_signup';
					$this->Email->sendAs 	= 'both';
					$this->set('User', $user);
					$this->Email->send();
					$this->redirect(array('controller'=>'users','action'=>'signup_confirm/'.$insert_id,'prefix'=>'webadmin'));	
				} 
		}
	}
                    function webadmin_signup_confirm($id) {
		$this->layout='webadmin';
		$user = $this->User->findById($id);
		$this->set('user',$user); 
	}
	
	function webadmin_edit($id = null) {
		$this->layout='webadmin';
		if (!$id && empty($this->data)) {
			$this->Session->setFlash('Updation not successfully','flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if($this->data){
			if($this->User->save($this->data)){
				$this->Session->setFlash('User details updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
		$this->set('users', $this->User->findById($id));
	}
	
	 function webadmin_delete($id) {		 
		if($this->User->delete($id)){
			$this->Session->setFlash('User deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/users');
	}
	
	function webadmin_changestatus($id) {
		$this->autoRender =false;
		$user = $this->User->findById($id);
                                    
		$admin = $this->User->findById(23);
		if($user['User']['status']=='1'){
                                                      
			$user['User']['status'] = '0'; 
				$this->Email->to 		= $user['User']['email'];
				$this->Email->subject 	= 'Account de-activated';
				$this->Email->replyTo 	= $admin['User']['email'];
				$this->Email->from 		= "Event notification <".$admin['User']['email'].">";
				$this->Email->template 	= 'account_deactivated_noti';
				$this->Email->sendAs 	= 'both';
				$this->set('User', $user);
				$this->set('admin', $admin);
				$this->Email->send();
		}
		elseif($user['User']['status']=='0'){
			$user['User']['status'] = '1';
			if($user['User']['is_activated']=='0'){	
				$passToken = $this->generateRandomString();
				$user['User']['password_hint'] = $passToken;
				$user['User']['password'] = Security::hash($passToken, null, true);
				$this->Email->to 		= $user['User']['email'];
				$this->Email->subject 	= 'Account activated - DO NOT REPLY';
				$this->Email->replyTo 	= $admin['User']['email'];
				$this->Email->from 		= "Event notification <".$admin['User']['email'].">";
				$this->Email->template 	= 'account_activated_noti';
				$this->Email->sendAs 	= 'both';
				$this->set('User', $user);
				$this->Email->send();
				$user['User']['is_activated'] = '1';
			}
			else{
				$this->Email->to 		= $user['User']['email'];
				$this->Email->subject 	= 'Account activated - DO NOT REPLY';
				$this->Email->replyTo 	= $admin['User']['email'];
				$this->Email->from 		= "Event notification <".$admin['User']['email'].">";
				$this->Email->template 	= 'account_activated_noti';
				$this->Email->sendAs 	= 'both';
				$this->set('User', $user);
				$this->Email->send();
			}
		}
                 //pr($user);die();
		if($this->User->save($user,array( 'validate' => false))){
			$this->Session->setFlash('User status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/users');
	}
        		  function webadmin_changestatusall() {
		$this->autoRender =false;
		if(!empty($_POST['chk'])){ 
			$usrArr = $_POST['chk'];
			$admin = $this->User->findById(23);
			if($this->data['User']['sel_action']=='publish'){
				foreach($_POST['chk'] as $v){
					$user = $this->User->findById($v);
					$user['User']['status']='1';
					if($user['User']['is_activated']=='0'){
						$passToken = $this->generateRandomString();
						$user['User']['password_hint'] = $passToken;
						$user['User']['password'] = Security::hash($passToken, null, true);
						$this->Email->to 		= $user['User']['email'];
						$this->Email->subject 	= 'Account activated - DO NOT REPLY';
						$this->Email->replyTo 	= $admin['User']['email'];
						$this->Email->from 		= "Event notification <".$admin['User']['email'].">";
						$this->Email->template 	= 'account_activated_noti';
						$this->Email->sendAs 	= 'both';
						$this->set('User', $user);
						$this->Email->send();
						$user['User']['is_activated'] = '1';
					}
					else{
						$this->Email->to 		= $user['User']['email'];
						$this->Email->subject 	= 'Account activated - DO NOT REPLY';
						$this->Email->replyTo 	= $admin['User']['email'];
						$this->Email->from 		= "Event notification <".$admin['User']['email'].">";
						$this->Email->template 	= 'account_activated_noti';
						$this->Email->sendAs 	= 'both';
						$this->set('User', $user);
						$this->Email->send();
					}
					$this->User->save($user,array( 'validate' => false));
				}
				$this->Session->setFlash('Selected Users Activated successfully','flash_success');
			}
			elseif($this->data['User']['sel_action']=='unpublish'){ 
				foreach($usrArr as $v){
					$user = $this->User->findById($v);
					$user['User']['status']='0';
					$this->Email->to 		= $user['User']['email'];
					$this->Email->subject 	= 'Account de-activated';
					$this->Email->replyTo 	= $admin['User']['email'];
					$this->Email->from 		= "Event notification <".$admin['User']['email'].">";
					$this->Email->template 	= 'account_deactivated_noti';
					$this->Email->sendAs 	= 'both';
					$this->set('User', $user);
					$this->set('admin', $admin);
					$this->Email->send();
					$this->User->save($user,array( 'validate' => false));
				}
				$this->Session->setFlash('Selected Users De-activated successfully','flash_success');
			}
			elseif($this->data['User']['sel_action']=='delete'){
				foreach($_POST['chk'] as $v){
					$this->User->delete($v);
				}
				$this->Session->setFlash('Selected Users deleted successfully','flash_success');
			}
		} 
		else{
			$this->Session->setFlash('Please select the users.','flash_error');
		}	
		$this->redirect('/webadmin/users');
	}
                 function webadmin_details($id) {
		$this->layout='webadmin';
		$this->set('user', $this->User->findById($id));
	}
        
               function webadmin_generate_password($id=null) {
		$this->autoRender=false;
		//echo $id;
		if(empty($id)){
			$this->redirect(array('controller'=>'dashboard','action'=>'index','prefix'=>'webadmin'));
		}
		$user = $this->User->findById($id);
		$admin = $this->User->findById(23);
		
		$passToken = $this->generateRandomString();
		$user['User']['password_hint'] = $passToken;
		$user['User']['password'] = Security::hash($passToken, null, true);
		$this->Email->to 		= $user['User']['email'];
		$this->Email->subject 	= 'Password changed - DO NOT REPLY';
		$this->Email->replyTo 	= $admin['User']['email'];
		$this->Email->from 		= "Event notification <".$admin['User']['email'].">";
		$this->Email->template 	= 'change_password';
		$this->Email->sendAs 	= 'both';
		$this->set('User', $user);
		if($this->Email->send()){
                                  if($this->User->save($user,array( 'validate' => true, 'fieldList' => array('password','password_hint') ))){
			
                            $this->Session->setFlash('Password changed successfully','flash_success');	
				$this->redirect(array('controller'=>'users','action'=>'index','prefix'=>'webadmin'));
			}
		}
		else{
			$this->Session->setFlash('Error occured. Try again.','flash_error');
			$this->redirect(array('controller'=>'users','action'=>'index','prefix'=>'webadmin'));
		}
		
	} 
        
	
	
	/*==============================FRONT END FUNCTIONS START==================================*/
		
	function signup() {
		$this->layout='frontend';
		$this->set('guideline',$this->Guideline->findByPage('signup'));
		if($this->data){
			if($this->Recaptcha->verify()) {
				$this->data['User']['ref_no'] = mt_rand(10000, 99999);
				if($this->User->save($this->data)){
					$insert_id=$this->User->getLastInsertID();
					$user = $this->User->findById($insert_id);
                                        $admin = $this->User->findById(23);
					$this->Email->to 		= $user['User']['email'];
					$this->Email->subject 	= 'Account Created Notification';
					$this->Email->replyTo 	= $admin['User']['email'];
					$this->Email->from 		= 'BlueFast notification <'.$admin['User']['email'].'>';
					$this->Email->template 	= 'signup_noti';
					$this->Email->sendAs 	= 'both';
					$this->set('User', $user);
					$this->Email->send();
					$this->redirect(array('controller'=>'users','action'=>'signup_confirm',$insert_id));	
				} 
			}else{
				$this->Session->setFlash('Error occured.'.$this->Recaptcha->error,'front_error');
			}
		}
	}
	
	function signup_confirm($id) {
		$this->layout='frontend';
		$user = $this->User->findById($id);
		$this->set('refer_id',$user['User']['ref_no']); 
	}
	
	function login_type() {
		$this->layout='frontend';
	}

	
	
	/**
     * Allow user to confirm account if $token is valid.
     * @return
     */
    function confirm_account_token($confirm_account_token = null) {
		$this->layout='frontend';
		$this->autoRender = false;
		$user = $this->User->findByConfirmAccountToken($confirm_account_token);
		if($user){
			$this->User->id    = $user['User']['id'];
			if ($this->User->saveField('status', '1') && $this->__sendAccountConfirmedEmail($this->User->id)) {			
				$this->Session->setflash('Your account was confirmed successfully. Please login to continue.','front_success');
				$this->redirect(array('controller'=>'login','action'=>'index'));
			}
		}
		else{
			$this->Session->setflash('The confirm account request is invalid.','front_error');
		}
    }
	
	function forgotpassword() {
		$this->layout='frontend';
		if($this->data){
			$user = $this->User->findByEmail($this->data['User']['email']);
            if (empty($user)) {
                $this->Session->setflash('Sorry, the email entered was not found.');
                $this->redirect('/users/forgotpassword');
            } else {
                $user = $this->__generatePasswordToken($user);
                if ($this->User->save($user) && $this->__sendForgotPasswordEmail($user['User']['id'])) {
                    $this->Session->setflash('Password reset instructions have been sent to your email address.
						You have 24 hours to complete the request.','front_success');
                    $this->redirect(array('controller'=>'login','action'=>'index'));
                }
            }
		}
	}
	/**
     * Allow user to reset password if $token is valid.
     * @return
     */
    function reset_password_token($reset_password_token = null) {
		$this->layout='frontend';
        if (empty($this->data)) {
            $this->data = $this->User->findByResetPasswordToken($reset_password_token);
            if (!empty($this->data['User']['reset_password_token']) && !empty($this->data['User']['token_created_at']) &&
            $this->__validToken($this->data['User']['token_created_at'])) {
                $this->data['User']['id'] = null;
                $_SESSION['token'] = $reset_password_token;
            } else {
                $this->Session->setflash('The password reset request has either expired or is invalid.','front_error');
                $this->redirect(array('controller'=>'login','action'=>'index'));
            }
        } else {
            if ($this->data['User']['reset_password_token'] != $_SESSION['token']) {
                $this->Session->setflash('The password reset request has either expired or is invalid.','front_error');
                $this->redirect(array('controller'=>'login','action'=>'index'));
            }

            $user = $this->User->findByResetPasswordToken($this->data['User']['reset_password_token']);
            $this->User->id = $user['User']['id'];

            if ($this->User->save($this->data, array('validate' => 'only'))) {
                $this->data['User']['reset_password_token'] = $this->data['User']['token_created_at'] = null;
                if ($this->User->save($this->data) && $this->__sendPasswordChangedEmail($user['User']['id'])) {
                    unset($_SESSION['token']);
                    $this->Session->setflash('Your password was changed successfully. Please login to continue.','front_success');
                    $this->redirect(array('controller'=>'login','action'=>'index'));
                }
            }
        }
    }
	
	
	function checkuser() {
		$this->autoRender=false;
		if (isset($_SESSION['Auth']['User'])){
			if($_SESSION['Auth']['User']['type']=='renter'){
				$this->redirect(array('controller'=>'filters','action'=>'index'));
			}
			elseif($_SESSION['Auth']['User']['type']=='landlord'){
				$this->redirect(array('controller'=>'users','action'=>'userprofile'));
			}
		}
	}
	
	function userprofile() {
		$this->layout='frontend';
		$this->set('user', $this->User->findById($this->Auth->user('id')));
		$this->paginate = array( 
		   'limit' =>4,
		   'order' => array('Listing.id' => 'DESC')
		);
		$this->set('listings', $this->paginate('Listing',array('Listing.userid'=>$this->Auth->user('id'))));
	}
		
	function edit_profile() {
		$this->layout='frontend';
		if($this->data){
			$this->data['User']['id'] = $this->Auth->user('id');
			$this->User->set($this->data);
			$errors = $this->User->invalidFields();
			if($errors){
				$this->Session->setFlash($errors,'flash_errors');
			}
			else{
				if($this->User->save($this->data)){
					$this->Session->setFlash('Your profile details updated successfully','flash_success');
					$this->redirect(array('controller' => 'users','action' => 'edit_profile'));
				}
			}
		}
		$this->set('user', $this->User->findById($this->Auth->user('id')));
	}
	 
	
	
	function change_password() {
		$this->layout='frontend';
		$this->autoRender = false;
		if($this->data){
			$this->data['User']['id'] = $this->Auth->user('id');
			$this->User->set($this->data);
			$errors = $this->User->invalidFields();
			if($errors){
				$this->Session->setFlash($errors,'flash_errors');
				$this->redirect(array('controller' => 'users','action' => 'edit_profile'));
			}
			else{
				if($this->User->save($this->data)) {
					$this->Session->setFlash('Password has been changed.','flash_success');
					$this->redirect(array('controller' => 'users','action' => 'edit_profile'));
				}
			}
		}
	}
	
	/*==============================FRONT END FUNCTIONS END==================================*/
	
	 /**
     * Generate a unique hash / token.
     * @param Object User
     * @return Object User
     */
    function __generatePasswordToken($user) {
        if (empty($user)) {
            return null;
        }

        // Generate a random string 100 chars in length.
        $token = "";
        for ($i = 0; $i < 100; $i++) {
            $d = rand(1, 100000) % 2;
            $d ? $token .= chr(rand(33,79)) : $token .= chr(rand(80,126));
        }

        (rand(1, 100000) % 2) ? $token = strrev($token) : $token = $token;

        // Generate hash of random string
        $hash = Security::hash($token, 'sha256', true);;
        for ($i = 0; $i < 20; $i++) {
            $hash = Security::hash($hash, 'sha256', true);
        }

        $user['User']['reset_password_token'] = $hash;
		$user['User']['confirm_account_token'] = $hash;
        $user['User']['token_created_at']     = date('Y-m-d H:i:s');

        return $user;
    }

    /**
     * Validate token created at time.
     * @param String $token_created_at
     * @return Boolean
     */
    function __validToken($token_created_at) {
        $expired = strtotime($token_created_at) + 86400;
        $time = strtotime("now");
        if ($time < $expired) {
            return true;
        }
        return false;
    }

    /**
     * Sends password reset email to user's email address.
     * @param $id
     * @return
     */
    function __sendForgotPasswordEmail($id = null) {
        if (!empty($id)) {
            $this->User->id = $id;
            $User = $this->User->read();

            $this->Email->to 		= $User['User']['email'];
            $this->Email->subject 	= 'Password Reset Request - DO NOT REPLY';
            $this->Email->replyTo 	= 'do-not-reply@rentalus.com';
            $this->Email->from 		= 'Do Not Reply <do-not-reply@rentalus.com>';
            $this->Email->template 	= 'reset_password_request';
            $this->Email->sendAs 	= 'both';
            $this->set('User', $User);
            $this->Email->send();

            return true;
        }
        return false;
    }
	
	/**
     * Sends confirm account email to user's email address.
     * @param $email
     * @return
     */
	function __sendConfirmAccountEmail($email = null) {
        if (!empty($email)) {
            $this->User->email = $email;
            $User = $this->User->read();

            $this->Email->to 		= $User['User']['email'];
            $this->Email->subject 	= 'Confirm Account Request - DO NOT REPLY';
            $this->Email->replyTo 	= 'admin@rentalus.com';
            $this->Email->from 		= 'Do Not Reply <admin@rental.us.com>';
            $this->Email->template 	= 'confirm_account_request';
            $this->Email->sendAs 	= 'both';
            $this->set('User', $User);
            $this->Email->send();

            return true;
        }
        return false;
    }
	/**
     * Notifies user their account has been confirmed.
     * @param $id
     * @return
     */
    function __sendAccountConfirmedEmail($id = null) {
        if (!empty($id)) {
            $this->User->id = $id;
            $User = $this->User->read();

            $this->Email->to 		= $User['User']['email'];
            $this->Email->subject 	= 'Account Confirmed - DO NOT REPLY';
            $this->Email->replyTo 	= 'do-not-reply@example.com';
            $this->Email->from 		= 'Do Not Reply <do-not-reply@example.com>';
            $this->Email->template 	= 'account_confirm_success';
            $this->Email->sendAs 	= 'both';
            $this->set('User', $User);
            $this->Email->send();

            return true;
        }
        return false;
    }

    /**
     * Notifies user their password has changed.
     * @param $id
     * @return
     */
    function __sendPasswordChangedEmail($id = null) {
        if (!empty($id)) {
            $this->User->id = $id;
            $User = $this->User->read();

            $this->Email->to 		= $User['User']['email'];
            $this->Email->subject 	= 'Password Changed - DO NOT REPLY';
            $this->Email->replyTo 	= 'do-not-reply@example.com';
            $this->Email->from 		= 'Do Not Reply <do-not-reply@example.com>';
            $this->Email->template 	= 'password_reset_success';
            $this->Email->sendAs 	= 'both';
            $this->set('User', $User);
            $this->Email->send();

            return true;
        }
        return false;
    }
	
	
	/*function signup() {
		$this->layout='frontend';
		$this->set('guideline',$this->Guideline->findByPage('signup'));
		if($this->data){
			//pr($this->data);
			$this->User->set($this->data);
			$errors = $this->User->invalidFields();
			if (!$this->Recaptcha->verify()) {
				$errors[] = $this->Recaptcha->error.'. Try Again.';
			}
			if($errors){
				$this->Session->setFlash($errors,'flash_errors');
				$this->redirect(array('controller' => 'users','action' => 'signup'));
			}
			else{
				if($this->User->save($this->data)){
					$insert_id=$this->User->getLastInsertID();
					$this->redirect(array('controller'=>'users','action'=>'signup_confirm',$insert_id));	
				} 
				else{
					$this->Session->setFlash('Error occured.','flash_error');
				}
			}
		}
	}*/
}
?>