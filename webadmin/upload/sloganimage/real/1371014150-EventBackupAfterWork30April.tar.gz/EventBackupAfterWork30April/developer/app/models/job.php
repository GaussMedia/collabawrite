<?php
class Job extends AppModel {
	var $name = 'Job';
	var $validate = array(
		'post' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter a job post',
			),
		),
		'detail' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter job description',
			),
		),
                'job_link' => array(
			'url' => array(
				'rule' => array('url', true),
				'message' => 'Please enter a valid url with http or https',
			),
		),
		
   );
}