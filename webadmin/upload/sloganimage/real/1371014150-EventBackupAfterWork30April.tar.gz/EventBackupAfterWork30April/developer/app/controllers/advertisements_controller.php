<?php
class AdvertisementsController extends AppController {

	var $name = 'Advertisements';
                  var $uses = array('Advertisement');  
        
                   function webadmin_add() {
		$this->layout='webadmin';
		if($this->data){
			$RandomNumber 	= rand(0, 9999999999); 
			$ImageName 		= str_replace(' ','-',strtolower($this->data['Ad']['image']['name'])); 
			$ImageSize 		= $this->data['Ad']['image']['size']; 
			$TempSrc	 	= $this->data['Ad']['image']['tmp_name'];
			$ImageType	 	= $this->data['Ad']['image']['type']; 
			$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
			$ImageExt = str_replace('.','',$ImageExt);
			$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
			$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
			move_uploaded_file($TempSrc,INCLUDE_PATH.'ads/'.$NewImageName);
			$this->data['Ad']['image']=$NewImageName;
			if($this->Ad->save($this->data)){
				$this->Session->setFlash('Ad inserted successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
	}
                function webadmin_index() {
		$this->layout='webadmin';		
		$this->paginate = array( 
			'limit' =>10,
            		//'conditions'=>array('type'=>'doctor'),
			'order' => array('Advertisement.id' => 'asc'));
			$advertisements = $this->paginate('Advertisement');		
		$this->set('advertisements', $advertisements);
	}
                 function webadmin_edit($id = null) {
		$this->layout='webadmin';
		$slider=$this->Advertisement->findById($id);
		$this->set('sliders',$slider);
		if (!$id && empty($this->data)) {
			$this->Session->setFlash('Updation not successfull','flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if($this->data){
			if(!empty($this->data['Advertisement']['image']['name'])){
				$RandomNumber 	= rand(0, 9999999999); 
				$ImageName 		= str_replace(' ','-',strtolower($this->data['Advertisement']['image']['name'])); 
				$ImageSize 		= $this->data['Advertisement']['image']['size']; 
				$TempSrc	 	= $this->data['Advertisement']['image']['tmp_name'];
				$ImageType	 	= $this->data['Advertisement']['image']['type']; 
				$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
				$ImageExt = str_replace('.','',$ImageExt);
				$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
				$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
                                @unlink(INCLUDE_PATH.'advertisements/'.$slider['Advertisement']['image']);
				if(move_uploaded_file($TempSrc,INCLUDE_PATH.'advertisements/'.$NewImageName)){
					
					$this->data['Advertisement']['image']=$NewImageName;	
				}
			}
			else{
					$this->data['Advertisement']['image']=$slider['Advertisement']['image'];	
			}
			
			if($this->Advertisement->save($this->data)){
				$this->Session->setFlash('Advertisement details updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
		
	}
        
                function webadmin_changestatus($id) {
		$this->autoRender =false;
		$slider = $this->Advertisement->findById($id);
		if($slider['Advertisement']['status']=='1'){
			$slider['Advertisement']['status'] = '0';
		}
		elseif($slider['Advertisement']['status']=='0'){
			$slider['Advertisement']['status'] = '1';
		}
		if($this->Advertisement->save($slider)){
			$this->Session->setFlash('Advertisement status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/advertisements');
	}
        
                  
}
?>