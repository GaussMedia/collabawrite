<?php
class DashboardController extends AppController {

	var $name = 'Dashboard';
	var $uses = array('Admin','User','Page','Event','Advertisement','Location');
var $components = array('Recaptcha.Recaptcha');  
	function beforeFilter() {    
		parent::beforeFilter(); 
        $this->Auth->allow(array('index','contactus','contactusform'));
		if(isset($this->params['prefix']) && $this->params['prefix'] == 'webadmin' and ($this->Auth->user('type')!='superadmin')) {
			$this->redirect(array('controller'=>'login','action'=>'index','prefix'=>'webadmin'));
		}
    } 
	
	function webadmin_index() {  
		$this->layout='webadmin';
                
		$this->set('user_count',$this->User->find('count'));
		///Change Password Request count//////
		$change_password_request_count=$this->User->find('count',array('conditions'=>array('changepassword_request'=>'1')));
		$this->set('change_password_request_count',$change_password_request_count);
                
                $approval_req=$this->User->find('count',array('conditions'=>array('read'=>'0')));
		$this->set('approval_req',$approval_req);
		/////////////////////////////////////
		
	}
	
	function webadmin_changepass($id = null) {
		$this->layout='webadmin';
		if($this->data){
			$this->data['Admin']['id'] = $id;
			if($this->Admin->save($this->data)) {
				$this->Session->setFlash('Password has been changed.','flash_success');
			}
		}
		$this->data = $this->Admin->findById($this->Auth->user('id'));
	}
	
	function webadmin_editprofile() {
		$this->layout='webadmin';
		if($this->data){
			if($this->Admin->save($this->data)) {
				$this->Session->setFlash('Your Profile details has been changed successfully.','flash_success');
			}
		}
		$this->set('admin',$this->Admin->findById($this->Auth->user('id')));
	}
	
	function webadmin_editsociallinks() {
		$this->layout='webadmin';
		if($this->data){
			if($this->Admin->save($this->data)) {
				$this->Session->setFlash('Social links updated successfully.','flash_success');
			}
		}
		$this->set('admin',$this->Admin->findById($this->Auth->user('id')));
	}
	
	
	function webadmin_getInTouch() {
		$this->layout='webadmin';
		if($this->data){
			if($this->User->save($this->data)) {
				$this->Session->setFlash('Get in touch information updated successfully.','flash_success');
			}
		}
		$this->set('admin',$this->User->findById(23));
		
	}
	
	function webadmin_change_password_requests() {
		$this->layout='webadmin';
		$this->paginate = array( 
	    'limit' =>10,
		'conditions'=>array('changepassword_request'=>'1'),
	    'order' => array('User.id' => 'asc'));
		$users = $this->paginate('User');
		$this->set('users', $users);

	}
	
	function webadmin_generate_password($id=null) {
		$this->autoRender=false;
		//echo $id;
		if(empty($id)){
			$this->redirect(array('controller'=>'dashboard','action'=>'index','prefix'=>'webadmin'));
		}
		$user = $this->User->findById($id);
		$admin = $this->User->findById(23);
		
		$passToken = $this->generateRandomString();
		$user['User']['password_hint'] = $passToken;
		$user['User']['password'] = Security::hash($passToken, null, true);
		$user['User']['changepassword_request'] = 0;
		$this->Email->to 		= $user['User']['email'];
		$this->Email->subject 	= 'Password changed - DO NOT REPLY';
		$this->Email->replyTo 	= $admin['User']['email'];
		$this->Email->from 		= "BlueFast notification <".$admin['User']['email'].">";
		$this->Email->template 	= 'change_password';
		$this->Email->sendAs 	= 'both';
		$this->set('User', $user);
		if($this->Email->send()){
			
			if($this->User->save($user)){
				$this->Session->setFlash('Password changed successfully','flash_success');	
				$this->redirect(array('controller'=>'dashboard','action'=>'webadmin_change_password_requests','prefix'=>'webadmin'));
			}
		}
		else{
			$this->Session->setFlash('Error occured. Try again.','flash_error');
			$this->redirect(array('controller'=>'dashboard','action'=>'index','prefix'=>'webadmin'));
		}
		
	}

	

	/*==============================FRONT END FUNCTIONS START==================================*/
	function index() { 
                 
                        $this->layout='frontend';
                        $this->set('pagesIndex', $this->Page->find('all'));
                       //$this->set('sitemap1', $this->Indexpage->findById(4));
                        $this->set('advertisements', $this->Advertisement->find('first',array('conditions'=>array('status'=>'1'))));
                        $this->set('sliderSetting', $this->User->find('first', array('conditions'=>array('User.id'=>23))));

                        $days = new DatePeriod(new DateTime, new DateInterval('P1D'), 6);
                        $i=0;
                         
                        
                         //echo date("Y-m-d H:i:s",1367055900);
                        foreach ($days as $day) {
                              
                                $day_start_timestamp=strtotime(($day->format('Y-m-d H:i:s')));
                               //echo date("Y-m-d H:i:s",$day_start_timestamp).'<br>';
                              $day_end_timestamp= strtotime('+1 day', $day_start_timestamp);
                                //echo date("Y-m-d H:i:s",$day_end_timestamp).'<br>';
                                $sevenDays[$i]['day']= ucfirst($day->format('l'));
                                $sevenDays[$i]['month']=ucfirst($day->format('F'));
                                $sevenDays[$i]['year']=strtoupper($day->format('Y'));
                                $sevenDays[$i]['date']=strtoupper($day->format('d'));
                                $sevenDays[$i]['events']=$this->Event->find('all',array('conditions'=>array(
                                    'OR'=>array(
                                                array('AND'=>array("Event.starttimestamp<$day_end_timestamp","Event.endtimestamp>$day_start_timestamp")),
                                                array('AND'=>array("Event.starttimestamp>$day_start_timestamp","Event.endtimestamp<$day_end_timestamp"))
                                    )
                                )));
                                $i++;
                        }
                        //pr($sevenDays);
                        $this->set('sevenDays',$sevenDays);
	}
	
	function contactus() {
		$this->layout='frontend';
	}

	function contactusform() {
		$this->layout='frontend';
		if($this->data){
			if($this->Recaptcha->verify()) {
				if($this->Feedback->save($this->data)){
					$insert_id=$this->Feedback->getLastInsertID();
					$user = $this->Feedback->findById($insert_id);
                    $admin = $this->User->findById(23);
					/*$this->Email->to 		= $user['Feedback']['email'];
					$this->Email->subject 	= 'User Contact Us Request Received';
					$this->Email->replyTo 	= $admin['User']['email'];
					$this->Email->from 		= 'BlueFast notification <'.$admin['User']['email'].'>';
					$this->Email->template 	= 'signup_noti';
					$this->Email->sendAs 	= 'both';
					$this->set('User', $user);
					$this->Email->send();*/
					$this->Session->setFlash('Your request is submitted successfully.','front_success');
				} 
			}else{
				$this->Session->setFlash('Error occured.'.$this->Recaptcha->error,'front_error');
			}
		}
	}

	/*==============================FRONT END FUNCTIONS END==================================*/
}
?>