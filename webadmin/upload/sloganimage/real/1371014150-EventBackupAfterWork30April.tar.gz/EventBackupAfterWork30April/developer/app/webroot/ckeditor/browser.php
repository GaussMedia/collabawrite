<form action="upload.php" method="post" enctype="multipart/form-data">
<input type="file" name="upload"  />
<input type="submit" name="uploadbtn" value="upload">
</form>