<?php
class AdsController extends AppController {

	var $name = 'Ads';
                  var $uses = array('Ad');   
        
                   function webadmin_add() {
		$this->layout='webadmin';
		if($this->data){
			$RandomNumber 	= rand(0, 9999999999); 
			$ImageName 		= str_replace(' ','-',strtolower($this->data['Ad']['image']['name'])); 
			$ImageSize 		= $this->data['Ad']['image']['size']; 
			$TempSrc	 	= $this->data['Ad']['image']['tmp_name'];
			$ImageType	 	= $this->data['Ad']['image']['type']; 
			$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
			$ImageExt = str_replace('.','',$ImageExt);
			$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
			$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
                                      if($this->data['Ad']['image']['type']=='image/jpeg' || $this->data['Ad']['image']['type']=='image/gif'|| $this->data['Ad']['image']['type']=='image/png'){		
                                                      move_uploaded_file($TempSrc,INCLUDE_PATH.'ads/'.$NewImageName);
			$this->data['Ad']['image']=$NewImageName;
			if($this->Ad->save($this->data)){
				$this->Session->setFlash('Ad inserted successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
                                             }
                                             else{
                                                     $this->Session->setFlash('Image is invalid,Please use Image with extension( .jpg, .png, .gif) ','flash_error');
                                             }
                        
		}
	}
                function webadmin_index() {
		$this->layout='webadmin';		
		$this->paginate = array( 
			'limit' =>10,
            		//'conditions'=>array('type'=>'doctor'),
			'order' => array('Ad.id' => 'asc'));
			$ads = $this->paginate('Ad');		
		$this->set('ads', $ads);
	}
                 function webadmin_edit($id = null) {
		$this->layout='webadmin';
		$slider=$this->Ad->findById($id);
		$this->set('sliders',$slider);
		if (!$id && empty($this->data)) {
			$this->Session->setFlash('Updation not successfull','flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if($this->data){
                                                      $error=0;          
			if(!empty($this->data['Ad']['image']['name'])){
				$RandomNumber 	= rand(0, 9999999999); 
				$ImageName 		= str_replace(' ','-',strtolower($this->data['Ad']['image']['name'])); 
				$ImageSize 		= $this->data['Ad']['image']['size']; 
				$TempSrc	 	= $this->data['Ad']['image']['tmp_name'];
				$ImageType	 	= $this->data['Ad']['image']['type']; 
				$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
				$ImageExt = str_replace('.','',$ImageExt);
				$ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
				$NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
                                @unlink(INCLUDE_PATH.'ads/'.$slider['Ad']['image']);
                                              if($this->data['Ad']['image']['type']=='image/jpeg' || $this->data['Ad']['image']['type']=='image/gif'|| $this->data['Ad']['image']['type']=='image/png'){
			if(move_uploaded_file($TempSrc,INCLUDE_PATH.'ads/'.$NewImageName)){
					
					$this->data['Ad']['image']=$NewImageName;	
                                                    }
                                            } else{
                                                               $error=1;       
                                                               $this->Session->setFlash('Image is invalid,Please use Image with extension( .jpg, .png, .gif) ','flash_error');
                                                }
			}
			else{
                                                                                          $slider=$this->Ad->findById($this->data['Ad']['id']);	
					$this->data['Ad']['image']=$slider['Ad']['image'];	
			}
			
                                                if($error=='0'){
                                                         if($this->Ad->save($this->data)){
				$this->Session->setFlash('Ad details updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
                                                }
		}
		
	}
        
                function webadmin_changestatus($id) {
		$this->autoRender =false;
		$slider = $this->Ad->findById($id);
		if($slider['Ad']['status']=='1'){
			$slider['Ad']['status'] = '0';
		}
		elseif($slider['Ad']['status']=='0'){
			$slider['Ad']['status'] = '1';
		}
		if($this->Ad->save($slider)){
			$this->Session->setFlash('Ad status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/ads');
	}
        
                  
}
?>