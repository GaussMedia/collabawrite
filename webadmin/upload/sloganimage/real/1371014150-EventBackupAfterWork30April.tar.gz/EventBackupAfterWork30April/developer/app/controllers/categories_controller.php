<?php
class CategoriesController extends AppController {

	var $name = 'Categories';
                  var $uses = array('Category');
                  
              function webadmin_add() {
               
                    $this->layout='webadmin';
                    $this->set('categories',$this->Category->find('list',array( 'order' => 'id ASC')));
                    if($this->data){
                                            $count=$this->Category->find('count',array(
                                            'conditions'=>array(
                                                'cat_name'=>  $this->data['Category']['cat_name']))); 
                                            if(!empty($count)){
                                                $this->Session->setFlash('Category name already exists','flash_error');
                                            }
                                           else{
                                               $this->Category->save($this->data);
                        $this->Session->setFlash('Category inserted successfully','flash_success');
                        $this->redirect(array('action' => 'index'));

                                           }
                    }
                }
                function webadmin_index() {
		$this->layout='webadmin';		
		$this->paginate = array( 
                                    'limit' =>10,
                                    //'conditions'=>array('type'=>'event_manager'),
                                    'order' => array('Category.id' => 'asc'));
                                    $category = $this->paginate('Category');		
                                    $this->set('cats', $category);
                }
                function webadmin_delete($id) {		 
		if($this->Category->delete($id)){
			$this->Session->setFlash('Category deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/categories');
                }
               function webadmin_changestatusall() {
		$this->autoRender =false;
		$catArr = $_POST['chk'];
		if($this->data['Category']['sel_action']=='publish'){
			foreach($catArr as $v){
				$cate = $this->Category->findById($v);
				$cate['Category']['status']='1';
				$this->Category->save($cate);
			}
			$this->Session->setFlash('Selected Category Activated successfully','flash_success');
		}
		elseif($this->data['Category']['sel_action']=='unpublish'){ 
			foreach($catArr as $v){
				$cate = $this->Category->findById($v);
				$cate['Category']['status']='0';
				$this->Category->save($cate);
			}
			$this->Session->setFlash('Selected Category De-activated successfully','flash_success');
		}
		elseif($this->data['Category']['sel_action']=='delete'){
			foreach($catArr as $v){
				$this->Category->delete($v);
			}
			$this->Session->setFlash('Selected Category deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/categories');
	}
        
        function webadmin_changestatus($id) {
		$this->autoRender =false;
		$faqs = $this->Category->findById($id);
		if($faqs['Category']['status']=='1'){
			$faqs['Category']['status'] = '0';
		}
		elseif($faqs['Category']['status']=='0'){
			$faqs['Category']['status'] = '1';
		}
		if($this->Category->save($faqs)){
			$this->Session->setFlash('Category status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/categories');
	}
          function webadmin_edit($id = null) {
		$this->layout='webadmin';
		if (!$id && empty($this->data)) {
			$this->Session->setFlash('Updation not successfully','flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if($this->data){
			if($this->Category->save($this->data)){
				$this->Session->setFlash('Category details updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
		$this->set('categories', $this->Category->findById($id));
	}
}
?>