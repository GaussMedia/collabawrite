<?php
class EventsController extends AppController {

	var $name = 'Events';
                  var $uses = array('Event','User','Category','Country','County','Location');
                  function webadmin_add() {
                        $this->layout='webadmin';
                        $this->set('events',$this->Event->find('list',array( 'order' => 'id ASC')));
                        $this->set('countryoptions',$this->Country->find('list',array('fields'=>array('Country.id','Country.country'), 'order' => 'id ASC')));
                        $this->set('options',$this->Category->find('list',array('fields'=>array('Category.id','Category.cat_name'), 'order' => 'id ASC')));
                        if($this->data){
                                                $this->data['Event']['userid'] = $this->Auth->user('id');
                                                
                                                $count=$this->Event->find('count',array(
                                                'conditions'=>array(
                                                    'eventname'=>  $this->data['Event']['eventname']))); 
                                                if(!empty($count)){
                                                    $this->Session->setFlash('Event name already exists','flash_error');
                                                }
                                               else{
                                                    $RandomNumber 	= rand(0, 9999999999); 
                                                    $ImageName 		= str_replace(' ','-',strtolower($this->data['Event']['image']['name'])); 
                                                    $ImageSize 		= $this->data['Event']['image']['size']; 
                                                    $TempSrc	 	= $this->data['Event']['image']['tmp_name'];
                                                    $ImageType	 	= $this->data['Event']['image']['type']; 
                                                    $ImageExt = substr($ImageName, strrpos($ImageName, '.'));
                                                    $ImageExt = str_replace('.','',$ImageExt);
                                                    $ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
                                                    $NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
                                                   // pr($this->data);die();
                                                    if($this->data['Event']['image']['type']=='image/jpeg' || $this->data['Event']['image']['type']=='image/gif'|| $this->data['Event']['image']['type']=='image/png'){
                                                          
                                                                move_uploaded_file($TempSrc,INCLUDE_PATH.'eventimages/'.$NewImageName);
                                                                $this->data['Event']['image']=$NewImageName;
                                                                $this->data['Event']['starttimestamp']=  strtotime($this->data['Event']['startdate'].$this->data['Event']['starttime']);
                                                                $this->data['Event']['endtimestamp']=  strtotime($this->data['Event']['enddate'].$this->data['Event']['endtime']);
                                                                $this->Event->save($this->data);
                                                                $this->Session->setFlash('Event inserted successfully','flash_success');
                                                                $this->redirect(array('action' => 'index'));
                                                         }
                                                         else{
                                                                 $this->Session->setFlash('Image is invalid,Please use Image with extension( .jpg, .png, .gif) ','flash_error');
                                                         }
                                             }
                        }
                       
                }
                 function webadmin_index() {
		$this->layout='webadmin';		
		$this->paginate = array( 
                                    'limit' =>10,
                                    //'conditions'=>array('type'=>'event_manager'),
                                    'order' => array('Event.id' => 'asc'));
                                    $events=$this->Event->find('all');
		foreach($events as $event){
			$cat_name=$this->Category->findById($event['Event']['categoryid']);
			//pr($cat_name);
			$event['Event']['categoryid']=$cat_name['Category']['cat_name'];
			$allevents[]=$event;
		}
		//pr($allLinks);
		$this->set('events',$allevents);
                
                                    $category = $this->paginate('Event');		
                                    //$this->set('events', $category);
                }
                 function webadmin_delete($id) {		 
		if($this->Event->delete($id)){
			$this->Session->setFlash('Event deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/events');
                }
               function webadmin_changestatusall() {
		$this->autoRender =false;
		$catArr = $_POST['chk'];
		if($this->data['Event']['sel_action']=='publish'){
			foreach($catArr as $v){
				$cate = $this->Event->findById($v);
				$cate['Event']['status']='1';
				$this->Event->save($cate);
			}
			$this->Session->setFlash('Selected Event Activated successfully','flash_success');
		}
		elseif($this->data['Event']['sel_action']=='unpublish'){ 
			foreach($catArr as $v){
				$cate = $this->Event->findById($v);
				$cate['Event']['status']='0';
				$this->Event->save($cate);
			}
			$this->Session->setFlash('Selected Event De-activated successfully','flash_success');
		}
		elseif($this->data['Event']['sel_action']=='delete'){
			foreach($catArr as $v){
				$this->Event->delete($v);
			}
			$this->Session->setFlash('Selected Event deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/events');
	}
        
        function webadmin_changestatus($id) {
		$this->autoRender =false;
		$faqs = $this->Event->findById($id);
		if($faqs['Event']['status']=='1'){
			$faqs['Event']['status'] = '0';
		}
		elseif($faqs['Event']['status']=='0'){
			$faqs['Event']['status'] = '1';
		}
		if($this->Event->save($faqs)){
			$this->Session->setFlash('Event status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/events');
	}
        function webadmin_edit($id = null) {
                $this->layout='webadmin';
                if (!$id && empty($this->data)) {
                        $this->Session->setFlash('Updation not successfully','flash_error');
                        $this->redirect(array('action' => 'index'));
                }
                if($this->data){
                        $error=0;
                        if(!empty($this->data['Event']['image']['name'])){
                            $RandomNumber 	= rand(0, 9999999999); 
                            $ImageName 		= str_replace(' ','-',strtolower($this->data['Event']['image']['name'])); 
                            $ImageSize 		= $this->data['Event']['image']['size']; 
                            $TempSrc	 	= $this->data['Event']['image']['tmp_name'];
                            $ImageType	 	= $this->data['Event']['image']['type']; 
                            $ImageExt = substr($ImageName, strrpos($ImageName, '.'));
                            $ImageExt = str_replace('.','',$ImageExt);
                            $ImageName 		= preg_replace("/\\.[^.\\s]{3,4}$/", "", $ImageName); 
                            $NewImageName = $ImageName.'-'.$RandomNumber.'.'.$ImageExt;
                                @unlink(INCLUDE_PATH.'eventimages/'.$slider['Event']['image']);
                                if($this->data['Event']['image']['type']=='image/jpeg' || $this->data['Event']['image']['type']=='image/gif'|| $this->data['Event']['image']['type']=='image/png'){
                                       //echo 'sdfdsfds';
                                        if(move_uploaded_file($TempSrc,INCLUDE_PATH.'eventimages/'.$NewImageName)){
                                                $this->data['Event']['image']=$NewImageName;	
                                        }
                                } else{
                                        $error=1;       
                                        $this->Session->setFlash('Image is invalid,Please use Image with extension( .jpg, .png, .gif) ','flash_error');
                                }
                        }
                        else{
                                        $slider=$this->Event->findById($this->data['Event']['id']);	
                                         $this->data['Event']['image']=$slider['Event']['image'];	
                        }
                        if($error=='0'){
                                $this->data['Event']['starttimestamp']=  strtotime($this->data['Event']['startdate'].$this->data['Event']['starttime']);
                                $this->data['Event']['endtimestamp']=  strtotime($this->data['Event']['enddate'].$this->data['Event']['endtime']);
                                if($this->Event->save($this->data)){
                                        $this->Session->setFlash('Event details updated successfully','flash_success');
                                        $this->redirect(array('action' => 'index'));
                               }
                        }
	}
                $this->set('options',$this->Category->find('list',array('fields'=>array('Category.id','Category.cat_name'), 'order' => 'id ASC')));
                $this->set('events',$this->Event->find('list',array( 'order' => 'id ASC')));
                $this->set('event', $this->Event->findById($id));
                $this->set('countryoptions',$this->Country->find('list',array('fields'=>array('Country.id','Country.country'), 'order' => 'id ASC')));
                $this->set('options1',$this->County->find('list',array('fields'=>array('County.id','County.county'), 'order' => 'id ASC')));

        }
                function webadmin_getcounties($country_id,$county_id=null){
                                  $this->autoRender = false;
                                     $county_name=$this->County->find('all', array('conditions'=>array('County.country'=>$country_id)));
                                    // pr($county_name);
                                     echo "<select name='data[Event][county]' class='syana' required>";
                                  echo "<option value=''>Select county</option>";
                                     foreach($county_name as $county_names){ 
                                            if(!empty($county_id) and $county_names['County']['id']==$county_id){
                                                echo '<option selected value="'.$county_names['County']['id'].'">'.$county_names['County']['county'].'</option>';
                                            }
                                              else {
                                                  echo '<option value="'.$county_names['County']['id'].'">'.$county_names['County']['county'].'</option>';
                                              }
                                            
                                            } 
                                            echo "</select>";
                                   
               }
               
               
               function webadmin_getmunicipality($county_id=null,$municipalty_id=null){
                                  $this->autoRender = false;
                                     $municipality_name=$this->Location->find('all', array('conditions'=>array('Location.county'=>$county_id)));
                                    // pr($county_name);
                                     echo "<select name='data[Event][municipality]' class='syana' required>";
                                  
                                     foreach($municipality_name as $municipality_names){ 
                                            if(!empty($county_id) and $municipality_names['Location']['id']==$county_id){
                                                echo '<option selected value="'.$municipality_names['Location']['id'].'">'.$municipality_names['Location']['municipality'].'</option>';
                                            }
                                              else {
                                                  echo '<option value="'.$municipality_names['Location']['id'].'">'.$municipality_names['Location']['municipality'].'</option>';
                                              }
                                              
                                            } 
                                            echo "</select>";
                                   
               }
               
               
                  
}
?>
