<?php
class LocationsController extends AppController {

	var $name = 'Locations';
                  var $uses = array('Location','County','Country');  
                  
                  function webadmin_add() {
		$this->layout='webadmin';
                                    //$this->set('options',$this->County->find('list',array('fields'=>array('County.id','County.county'), 'order' => 'id ASC')));
                                    $this->set('countryoptions',$this->Country->find('list',array('fields'=>array('Country.id','Country.country'), 'order' => 'id ASC')));
                                   if($this->data){
                                       //pr($this->data);
                                       //die();
			if($this->Location->save($this->data)){
				$this->Session->setFlash('Location  added successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
	}
                 function webadmin_index() {
		$this->layout='webadmin';
		$this->paginate = array( 
		   'limit' =>10,
                                    'order' => array('Location.id' => 'asc'));
                                   // $locations=$this->Location->find('all');
//		foreach($locations as $location){
//			$location_name=$this->County->findById($location['Location']['county']);
//			//pr($cat_name);
//			$location['Location']['county']=$location_name['County']['county'];
//			$alllocations[]=$location;
//		}
		//pr($allLinks);
		//$this->set('locations',$alllocations);
                
                                    $locations = $this->paginate('Location');
		 $this->set('locations',$locations); 
	}
                 function webadmin_changestatus($id) {
		$this->autoRender =false;
		$faq = $this->Location->findById($id);
		if($faq['Location']['status']=='1'){
			$faq['Location']['status'] = '0';
		}
		elseif($faq['Location']['status']=='0'){
			$faq['Location']['status'] = '1';
		}
		if($this->Location->save($faq)){
			$this->Session->setFlash('Location status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/locations');
	}
	
	function webadmin_changestatusall() {
		$this->autoRender =false;
		$faqArr = $_POST['chk'];
		if($this->data['Location']['sel_action']=='publish'){
			foreach($faqArr as $v){
				$faqq = $this->Location->findById($v);
				$faqq['Location']['status']='1';
				$this->Location->save($faqq);
			}
			$this->Session->setFlash('Selected Location Activated successfully','flash_success');
		}
		elseif($this->data['Location']['sel_action']=='unpublish'){ 
			foreach($faqArr as $v){
				$faqq = $this->Location->findById($v);
				$faqq['Location']['status']='0';
				$this->Location->save($faqq);
			}
			$this->Session->setFlash('Selected Location De-activated successfully','flash_success');
		}
		elseif($this->data['Location']['sel_action']=='delete'){
			foreach($faqArr as $v){
				$this->Location->delete($v);
			}
			$this->Session->setFlash('Selected Location deleted successfully','flash_success');
		}
                                    else{
			$this->Session->setFlash('Please select the Location.','flash_error');
		}
		$this->redirect('/webadmin/locations');
	}
                function webadmin_delete($id) {
		if($this->Location->delete($id)){
			$this->Session->setFlash('Location deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/locations');
	}
                 function webadmin_edit($id = null) {
		$this->layout='webadmin';
		if($this->data){
			if($this->Location->save($this->data)){
				$this->Session->setFlash('Location updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
		$this->set('blogs', $this->Location->findById($id));
                                    $this->set('counties', $this->County->findById($id));
                                    $this->set('options',$this->County->find('list',array('fields'=>array('County.id','County.county'), 'order' => 'id ASC')));
                                    $this->set('countryoptions',$this->Country->find('list',array('fields'=>array('Country.id','Country.country'), 'order' => 'id ASC')));
                                   
	}
                 function webadmin_add_county() {
                                    $this->layout='webadmin';
                                    $this->set('countryoptions',$this->Country->find('list',array('fields'=>array('Country.id','Country.country'), 'order' => 'id ASC')));
		if($this->data){
			if($this->County->save($this->data)){
				$this->Session->setFlash('County added successfully','flash_success');
				$this->redirect(array('action' => 'counties'));
			}
		}

	}
                 function webadmin_counties() {
                     $this->layout='webadmin';
		$this->paginate = array( 
		   'limit' =>10,
                                    'order' => array('County.id' => 'asc'));
                                   $counties = $this->paginate('County');
		 $this->set('counties',$counties);               
                     
	}
                function webadmin_countychangestatusall() {
		$this->autoRender =false;
		$faqArr = $_POST['chk'];
		if($this->data['County']['sel_action']=='publish'){
			foreach($faqArr as $v){
				$faqq = $this->County->findById($v);
				$faqq['County']['status']='1';
				$this->County->save($faqq);
			}
			$this->Session->setFlash('Selected County Activated successfully','flash_success');
		}
		elseif($this->data['County']['sel_action']=='unpublish'){ 
			foreach($faqArr as $v){
				$faqq = $this->County->findById($v);
				$faqq['County']['status']='0';
				$this->County->save($faqq);
			}
			$this->Session->setFlash('Selected County De-activated successfully','flash_success');
		}
		elseif($this->data['County']['sel_action']=='delete'){
			foreach($faqArr as $v){
				$this->County->delete($v);
			}
			$this->Session->setFlash('Selected County deleted successfully','flash_success');
		}
                                    else{
			$this->Session->setFlash('Please select the County.','flash_error');
		}
		$this->redirect('/webadmin/locations/counties');
	}
                 function webadmin_countydelete($id) {
		if($this->County->delete($id)){
			$this->Session->setFlash('County deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/locations/counties');
	}
                 function webadmin_countychangestatus($id) {
		$this->autoRender =false;
		$faq = $this->County->findById($id);
		if($faq['County']['status']=='1'){
			$faq['County']['status'] = '0';
		}
		elseif($faq['County']['status']=='0'){
			$faq['County']['status'] = '1';
		}
		if($this->County->save($faq)){
			$this->Session->setFlash('County status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/locations/counties');
	}
                 function webadmin_editcounty($id=null) {
                                    $this->layout='webadmin';
		if($this->data){
			if($this->County->save($this->data)){
				$this->Session->setFlash('County updated successfully','flash_success');
				$this->redirect(array('action' => 'counties'));
			}
		}
		$this->set('county', $this->County->findById($id));
                                    $this->set('countryoptions',$this->Country->find('list',array('fields'=>array('Country.id','Country.country'), 'order' => 'id ASC')));
                                   

	}
                function webadmin_add_country() {
                    $this->layout='webadmin';
		if($this->data){
			if($this->Country->save($this->data)){
				$this->Session->setFlash('Country added successfully','flash_success');
				$this->redirect(array('action' => 'countries'));
			}
		}

	}
                function webadmin_countries() {
                    $this->layout='webadmin';
		$this->paginate = array( 
		   'limit' =>10,
		   'order' => array('Country.id' => 'asc'));
		$countries = $this->paginate('Country');   
		$this->set('countries', $countries );

	}
                function webadmin_countrychangestatus($id) {
		$this->autoRender =false;
		$faq = $this->Country->findById($id);
		if($faq['Country']['status']=='1'){
			$faq['Country']['status'] = '0';
		}
		elseif($faq['Country']['status']=='0'){
			$faq['Country']['status'] = '1';
		}
		if($this->Country->save($faq)){
			$this->Session->setFlash('Country status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/locations/countries');
	}
                function webadmin_countrychangestatusall() {
		$this->autoRender =false;
		$faqArr = $_POST['chk'];
		if($this->data['Country']['sel_action']=='publish'){
			foreach($faqArr as $v){
				$faqq = $this->Country->findById($v);
				$faqq['Country']['status']='1';
				$this->Country->save($faqq);
			}
			$this->Session->setFlash('Selected Country Activated successfully','flash_success');
		}
		elseif($this->data['Country']['sel_action']=='unpublish'){ 
			foreach($faqArr as $v){
				$faqq = $this->Country->findById($v);
				$faqq['Country']['status']='0';
				$this->Country->save($faqq);
			}
			$this->Session->setFlash('Selected Country De-activated successfully','flash_success');
		}
		elseif($this->data['Country']['sel_action']=='delete'){
			foreach($faqArr as $v){
				$this->Country->delete($v);
			}
			$this->Session->setFlash('Selected Country deleted successfully','flash_success');
		}
                                    else{
			$this->Session->setFlash('Please select the Country.','flash_error');
		}
		$this->redirect('/webadmin/locations/countries');
	}
                function webadmin_countrydelete($id) {
		if($this->Country->delete($id)){
			$this->Session->setFlash('Country deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/locations/countries');
	}
                function webadmin_editcountry($id=null) {
                                    $this->layout='webadmin';
		if($this->data){
			if($this->Country->save($this->data)){
				$this->Session->setFlash('Country updated successfully','flash_success');
				$this->redirect(array('action' => 'countries'));
			}
		}
		$this->set('country', $this->Country->findById($id));
                                   

	}
               function webadmin_getcounties($country_id,$county_id=null){
                                  $this->autoRender = false;
                                     $county_name=$this->County->find('all', array('conditions'=>array('County.country'=>$country_id)));
                                    // pr($county_name);
                                     echo "<select name='data[Location][county]' class='syana'>";
                                  
                                     foreach($county_name as $county_names){ 
                                            if(!empty($county_id) and $county_names['County']['id']==$county_id){
                                                echo '<option selected value="'.$county_names['County']['id'].'">'.$county_names['County']['county'].'</option>';
                                            }
                                              else {
                                                  echo '<option value="'.$county_names['County']['id'].'">'.$county_names['County']['county'].'</option>';
                                              }
                                              $i++;
                                            } 
                                            echo "</select>";
                                   
               } 
        
}
?>