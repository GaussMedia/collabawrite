$(document).ready(function(){
  $('.datetimepicker').datetimepicker({});
});
