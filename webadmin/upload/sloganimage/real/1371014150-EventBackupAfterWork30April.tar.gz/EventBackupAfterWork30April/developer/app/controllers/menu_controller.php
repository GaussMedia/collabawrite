<?php
class MenuController extends AppController {

	var $name = 'Menu';
                  var $uses = array('Menu');
                  
                  function webadmin_index() {
		$this->layout='webadmin';
		$this->paginate = array( 
		   'limit' =>5,
		   'order' => array('Menu.id' => 'asc'));
		$menus = $this->paginate('Menu');   
		$this->set('menus', $menus );
	}
	
	function webadmin_add() {
		$this->layout='webadmin';
		if($this->data){
			if($this->Menu->save($this->data)){
				$this->Session->setFlash('Menu item added successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
	}
                 function webadmin_details($id) {
		$this->layout='webadmin';
		$this->set('menu', $this->Menu->findById($id));
	}
                 function webadmin_changestatus($id) {
		$this->autoRender =false;
		$faq = $this->Menu->findById($id);
		if($faq['Menu']['status']=='1'){
			$faq['Menu']['status'] = '0';
		}
		elseif($faq['Menu']['status']=='0'){
			$faq['Menu']['status'] = '1';
		}
		if($this->Menu->save($faq)){
			$this->Session->setFlash('Menu status changed successfully','flash_success');
		}
		$this->redirect('/webadmin/menu');
	}
	
	function webadmin_changestatusall() {
		$this->autoRender =false;
		$faqArr = $_POST['chk'];
		if($this->data['Menu']['sel_action']=='publish'){
			foreach($faqArr as $v){
				$faqq = $this->Menu->findById($v);
				$faqq['Menu']['status']='1';
				$this->Menu->save($faqq);
			}
			$this->Session->setFlash('Selected Menu Activated successfully','flash_success');
		}
		elseif($this->data['Menu']['sel_action']=='unpublish'){ 
			foreach($faqArr as $v){
				$faqq = $this->Menu->findById($v);
				$faqq['Menu']['status']='0';
				$this->Menu->save($faqq);
			}
			$this->Session->setFlash('Selected Menu De-activated successfully','flash_success');
		}
		elseif($this->data['Menu']['sel_action']=='delete'){
			foreach($faqArr as $v){
				$this->Menu->delete($v);
			}
			$this->Session->setFlash('Selected Menu deleted successfully','flash_success');
		}
                                    else{
			$this->Session->setFlash('Please select the Menu.','flash_error');
		}
		$this->redirect('/webadmin/menu');
	}
                function webadmin_delete($id) {
		if($this->Menu->delete($id)){
			$this->Session->setFlash('Menu deleted successfully','flash_success');
		}
		$this->redirect('/webadmin/menu');
	}
                function webadmin_edit($id = null) {
		$this->layout='webadmin';
		if($this->data){
			if($this->Menu->save($this->data)){
				$this->Session->setFlash('Menu updated successfully','flash_success');
				$this->redirect(array('action' => 'index'));
			}
		}
		$this->set('blogs', $this->Menu->findById($id));
	}
                  
}
?>