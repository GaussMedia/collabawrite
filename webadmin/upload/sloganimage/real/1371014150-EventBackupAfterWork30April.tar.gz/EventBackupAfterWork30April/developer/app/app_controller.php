<?php
class AppController extends Controller {
	  var $components = array(/*'AutoLogin',*/'Auth', 'Cookie', 'Session','Email'/*,'DebugKit.Toolbar'*/);
      public $helpers = array('Html', 'Form', 'Time', 'Session', 'Javascript', 'Cksource','Ekopp');
	  var $uses = array('Page','User','Logo','Ad');

function beforeRender() { 
                  $this->set('LogoImage', $this->Logo->find('first')); 
                  $this->set('ad', $this->Ad->find('first',array('conditions'=>array('status'=>'1'))));
                 //pr($this->Ad->find('first',array('conditions'=>array('status'=>'1'))));
                  //////////login logs/////////////
	$this->loadModel('Loginlog');	
	$logs=$this->Loginlog->find('all',array('conditions'=>array('user_id'=>$this->Auth->user('id')),'limit'=>2,'order'=>'created desc'));
	$this->set('logs',$logs);
	//////////login logs end/////////////
	$this->set('ip',$_SERVER['REMOTE_ADDR']);	
} 
	  
public function beforeFilter(){
        date_default_timezone_set("Asia/Calcutta");
parent::beforeFilter();
	 $this->Auth->allow(array('checkunm','checkemail','checkphone'));
	
	  
if(isset($this->params['prefix']) && $this->params['prefix'] == 'webadmin') {
$this->Auth->userModel = 'User';
$this->Auth->userScope = array('User.type'=>'superadmin');
$this->Auth->logoutRedirect = $this->Auth->loginAction = array('prefix' => 'webadmin', 'controller' => 'login', 'action' => 'index');
$this->Auth->loginError = 'Invalid Username/Password Combination!';
$this->Auth->authError = 'Please login to view this page!';
 $this->Auth->flashElement = "auth.front.message";
$this->Auth->loginRedirect = array('prefix'=>'webadmin', 'controller'=>'dashboard', 'action'=>'index');
	}
else{
	
 $this->Auth->userModel = 'User';
 $this->Auth->logoutRedirect = $this->Auth->loginAction = array('controller' => 'login', 'action' => 'index','prefix'=>'');
$this->Auth->userScope = array('User.status'=>1);
 //$this->Auth->fields = array('username' => 'username','password' => 'password1');
 $this->Auth->loginError = 'Invalid Username/Password Combination!';
 $this->Auth->authError = 'Please login to view this page!';
 $this->Auth->flashElement = "auth.front.message";
 $this->Auth->loginRedirect = array('controller' => 'eventmanager', 'action' => 'index','prefix'=>'');  
}
}


	
	public function checkunm(){
		$this->autoRender = false;
		$request = trim(strtolower($_REQUEST['data']['User']['username']));
		$usr = $this->User->find('count', array('conditions'=>array('User.username'=>$request)));
		if($usr==0){
			echo 'true';	
		}else{
			echo 'false';	
		}
	}
        
	
	public function checkemail(){
		$this->autoRender = false; 
		$request = trim(strtolower($_REQUEST['data']['User']['email']));
		$usr = $this->User->find('count', array('conditions'=>array('User.email'=>$request)));
		if($usr==0){
			echo 'true';	
		}else{
			echo 'false';	
		}
	}
	
	public function checkphone(){
		$this->autoRender = false;
		$request = trim(strtolower($_REQUEST['data']['User']['phone']));
		$usr = $this->User->find('count', array('conditions'=>array('User.phone'=>$request,'User.type'=>'landlord')));
		if($usr==0){
			echo 'true';	
		}else{
			echo 'false';	
		}
	}
	
	
	public function get_data($url) {
	  $ch = curl_init();
	  $timeout = 5;
	  curl_setopt($ch, CURLOPT_URL, $url);
	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	  $data = curl_exec($ch);
	  curl_close($ch);
	  return $data;
	}
	
	public function grab_image($url,$saveto){
		$ch = curl_init ($url);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
		$raw=curl_exec($ch);
		curl_close ($ch);
		if(file_exists($saveto)){
			unlink($saveto);
		}
		$fp = fopen($saveto,'x');
		fwrite($fp, $raw);
		fclose($fp);
	}
	
	function slug($string,$space="-") {
		$string = trim($string);
		if (function_exists('iconv')) {
			$string = @iconv('UTF-8', 'ASCII//TRANSLIT', $string);
		}
		$string = preg_replace("/[^a-zA-Z0-9 -]/", "", $string);
		$string = strtolower($string);
		$string = str_replace(" ", $space, $string);
		return $string;
	}
	function idbyslug($slug,$table){
		$idar=$this->$table->findBySlug($slug,'id');
		$id=$idar[$table]['id'];
		return $id;
	}
	function generateRandomString($length = 10) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $randomString;
	}
	
	function generateRandomRefNumber($length = 10) {
		$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return $randomString;
	}
	
}