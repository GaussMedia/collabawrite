<?php
class User extends AppModel {
	var $name = 'User';
	var $validate = array(
		'username' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your username',
			),
			'unique' => array(
				'rule' => array('isUnique'),
				'message' => 'Username already Exists',
				'on'=>'create',
			),
		),
		'first_name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your first name',
			),
		),
		'last_name' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your last name',
			),
		),
		'addressline1' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your Address Line 1',
			),
		),
		'mobile' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your mobile',
			),
		),
		'landline' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your landline',
			),
		),
		'companyname' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter your company name',
			),
		),
                                    
		
		'email' => array(
			'email' => array(
				'rule' => array('email'),
				'message' => 'Please enter your email',
			),
			'unique' => array(
				'rule' => array('isUnique'),
				'message' => 'Email already Exists',
				'on'=>'create',
			),
		),
		'agree' => array(
              'rule' => array('comparison', '==', 1),
              'required' => true,
              'message' => 'You must agree to the terms and conditions',
                'on' => 'create'
       )/*
	   'image'  => array(
            'checksize' => array(
                'rule' => array('checkSize',true),
                'message' => 'Invalid File size',
                'on' => 'create'
            ),
            'checktype' =>array(
                'rule' => array('checkType',true),
                'message' => 'File type not supported',
                'on' => 'create'
            )
		),
		'old_password' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Please enter old password',
			),
			'checkoldpass' => array(
				'rule' => 'checkCurrentPassword',
				'message' => 'Old password does not match'
			),
		),*/
	);
	
	public function checkCurrentPassword($data) {
		$password = $this->field('password');
		return(Security::hash($data['old_password'], null, true) == $password);
	}
	
    function checkType($data, $required = false,$allowedMime = null){
		$data = array_shift($data);
		if(isset($data['error'])){
			if(!$required && $data['error'] == 4){
				return true;
			}
			$allowedMime = array('image/gif','image/jpeg','image/pjpeg','image/png');
			if(!in_array($data['type'], $allowedMime)){
				 return false;
			}
		}
        return true;
    }

    function checkSize($data, $required = false){
        $data = array_shift($data);
		if(isset($data['error'])){
			if(!$required && $data['error'] == 4){
				return true;
			}
			if($data['size'] == 0||$data['size']/1024 > 2050){
				return false;
			}
		}
        return true;
    }
	
	public function checkpasswords(){ 
	   return strcmp($this->data['User']['password1'],$this->data['User']['password_confirmation']);
	}
    public function matchPasswords($data) {
        if($data['password1'] == $this->data[$this->alias]['password_confirmation']) return true;
        $this->invalidate('password_confirmation', 'Passwords do not match');
        return false;
    }
	public function hashPasswords($data) {
        if(isset($this->data[$this->alias]['password'])){
            $this->data[$this->alias]['password'] = Security::hash($this->data[$this->alias]['password'], null, true);
		}elseif(isset($this->data[$this->alias]['password1'])){
            $this->data[$this->alias]['password'] = Security::hash($this->data[$this->alias]['password1'], null, true);
		}elseif(isset($this->data[$this->alias]['new_passwd'])){
            $this->data[$this->alias]['password'] = Security::hash($this->data[$this->alias]['new_passwd'], null, true);
		}
        
        return $data;
    }
/*	public function beforeSave(array $options) {		
		$this->hashPasswords(null, true);
		if(isset($this->data['User']['image']['error'])){
			if($this->data['User']['image']['error']==0){
				$var1 = explode(".",$this->data['User']['image']['name']);
				if(count($var1[0])>10){
					$str = substr($this->data['User']['image']['name'],0,6);
				}
				else{
					$str = $this->data['User']['image']['name'];
				}
				$imgnm = trim('img'.time().$str);
				$imgnm = str_replace(" ","",$imgnm);
				move_uploaded_file($this->data['User']['image']['tmp_name'], 'img/users/'.$imgnm);	
				$this->data['User']['image'] = $imgnm;
			}
			else{
				unset($this->data['User']['image']);
			}
		}
		return true;
	}
*/}